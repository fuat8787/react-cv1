import React, {Component} from "react";
import About from "./components/About";
import logo from './images/fuat3.jpg';

import './App.css';
import Programming from "./components/Programming";
import Skills from "./components/Skills";
import Contact from "./components/Contact";

class App extends Component{
  render(){
    return(
      <div className="App"> 
        <h1>TEYMUR HAJIYEV</h1>
        <img src={logo} width='100' height='130'/>
        <About/>
        <Programming/>
        <Skills/>
        <Contact/>
      </div>
    )
  }
}
export default App;