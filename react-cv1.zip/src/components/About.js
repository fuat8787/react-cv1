import React, { Component } from 'react'

class About extends Component {
  render() {
    return (
      <div><h2>About</h2>
      
          <h2>İsmim Teymur . Trakya Üniversitesi Bilgisyar 
              mühendisliği 4. sınıf okuyorum <br/>
              -------------------------
          </h2>
      </div>
      
    )
  }
}
export default About;