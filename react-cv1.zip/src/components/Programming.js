import React, { Component } from 'react'

class Programming extends Component {
  render() {
    return (
      <div><h2>Programming</h2>
          <h2>
              - Html, Css, Javascript <br/>
              - React <br/>
              - MsSql <br/>
              - Python, C <br/>
              --------------------

          </h2>
      </div>
    )
  }
}
export default Programming;
