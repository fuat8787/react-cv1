import React, { Component } from 'react'

class Skills extends Component {
  render() {
    return (
      <div><h2>Skills</h2>
        <h2>- English A2 <br/>
            - Azerbaijan native speaker<br/>
            - To Play Voleybol <br/>
            - To Read Book <br/>
            - To Swim <br/>
            -------------------
        </h2>
      </div>
    )
  }
}
export default Skills;