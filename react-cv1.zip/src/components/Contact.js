import React, { Component } from 'react'

class Contact extends Component {
  render() {
    return (
      <div><h2>Contact</h2>
        <a href='https://github.com/fuat8787'><h2>Github hesabım</h2></a><br/>
        <a href='https://www.linkedin.com/in/teymur-hajiyev-6312161a5/'><h2>Linkedin hesabım</h2></a><br/>
        <h2>Mail: teymurhajiyev1@trakya.edu.tr</h2>
      </div>
    )
  }
}
export default Contact;